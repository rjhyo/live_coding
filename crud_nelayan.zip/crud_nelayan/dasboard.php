<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
</head>
<body>
    <h1>Dashboard</h1>
    <nav>
        <a href="nelayan.php">Kelola Data Nelayan</a><br>
        <a href="hasil_tangkapan.php">Kelola Hasil Tangkapan</a><br>
        <a href="stok_ikan.php">Kelola Stok Ikan</a><br>
        <a href="logout.php">Logout</a>
    </nav>
</body>
</html>
