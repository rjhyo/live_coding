<?php
include 'config.php';
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Menambahkan nelayan baru
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add'])) {
    $nama = $_POST['nama'];
    $alamat = $_POST['alamat'];
    $kontak = $_POST['kontak'];

    $stmt = $conn->prepare("INSERT INTO nelayan (nama, alamat, kontak) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $nama, $alamat, $kontak);
    $stmt->execute();
    $stmt->close();
}

// Menampilkan data nelayan
$result = $conn->query("SELECT * FROM nelayan");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Data Nelayan</title>
</head>
<body>
    <h2>Data Nelayan</h2>
    <form method="POST">
        <input type="text" name="nama" placeholder="Nama" required>
        <input type="text" name="alamat" placeholder="Alamat" required>
        <input type="text" name="kontak" placeholder="Kontak" required>
        <button type="submit" name="add">Tambah Nelayan</button>
    </form>

    <table>
        <tr>
            <th>Nama</th>
            <th>Alamat</th>
            <th>Kontak</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?php echo $row['nama']; ?></td>
            <td><?php echo $row['alamat']; ?></td>
            <td><?php echo $row['kontak']; ?></td>
        </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>
