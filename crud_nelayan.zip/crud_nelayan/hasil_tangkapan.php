<?php
include 'config.php';
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Tambah Hasil Tangkapan Baru
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add'])) {
    $nelayan_id = $_POST['nelayan_id'];
    $jenis_ikan = $_POST['jenis_ikan'];
    $jumlah = $_POST['jumlah'];
    $tanggal = $_POST['tanggal'];

    $stmt = $conn->prepare("INSERT INTO hasil_tangkapan (nelayan_id, jenis_ikan, jumlah, tanggal) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("isis", $nelayan_id, $jenis_ikan, $jumlah, $tanggal);
    $stmt->execute();
    $stmt->close();
}

// Ambil Data Nelayan untuk Opsi Pilihan
$nelayan_result = $conn->query("SELECT * FROM nelayan");

// Tampilkan Data Hasil Tangkapan
$tangkapan_result = $conn->query("SELECT hasil_tangkapan.*, nelayan.nama AS nama_nelayan FROM hasil_tangkapan JOIN nelayan ON hasil_tangkapan.nelayan_id = nelayan.id");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Data Hasil Tangkapan</title>
</head>
<body>
    <h2>Data Hasil Tangkapan</h2>
    
    <!-- Form Tambah Data Hasil Tangkapan -->
    <form method="POST">
        <label for="nelayan_id">Nelayan:</label>
        <select name="nelayan_id" required>
            <?php while ($nelayan = $nelayan_result->fetch_assoc()): ?>
                <option value="<?php echo $nelayan['id']; ?>"><?php echo $nelayan['nama']; ?></option>
            <?php endwhile; ?>
        </select>
        <input type="text" name="jenis_ikan" placeholder="Jenis Ikan" required>
        <input type="number" name="jumlah" placeholder="Jumlah" required>
        <input type="date" name="tanggal" required>
        <button type="submit" name="add">Tambah</button>
    </form>

    <!-- Tabel Data Hasil Tangkapan -->
    <table border="1">
        <tr>
            <th>Nama Nelayan</th>
            <th>Jenis Ikan</th>
            <th>Jumlah</th>
            <th>Tanggal</th>
            <th>Aksi</th>
        </tr>
        <?php while ($row = $tangkapan_result->fetch_assoc()): ?>
        <tr>
            <td><?php echo $row['nama_nelayan']; ?></td>
            <td><?php echo $row['jenis_ikan']; ?></td>
            <td><?php echo $row['jumlah']; ?></td>
            <td><?php echo $row['tanggal']; ?></td>
            <td>
                <a href="edit_hasil_tangkapan.php?id=<?php echo $row['id']; ?>">Edit</a> |
                <a href="delete_hasil_tangkapan.php?id=<?php echo $row['id']; ?>" onclick="return confirm('Yakin ingin menghapus data ini?');">Hapus</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>
