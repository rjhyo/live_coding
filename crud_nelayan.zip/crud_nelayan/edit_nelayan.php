<?php
include 'config.php';
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Tambah Stok Ikan Baru
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add'])) {
    $jenis_ikan = $_POST['jenis_ikan'];
    $jumlah = $_POST['jumlah'];
    $harga_per_kg = $_POST['harga_per_kg'];

    $stmt = $conn->prepare("INSERT INTO stok_ikan (jenis_ikan, jumlah, harga_per_kg) VALUES (?, ?, ?)");
    $stmt->bind_param("sid", $jenis_ikan, $jumlah, $harga_per_kg);
    $stmt->execute();
    $stmt->close();
}

// Tampilkan Data Stok Ikan
$stok_result = $conn->query("SELECT * FROM stok_ikan");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Data Stok Ikan</title>
</head>
<body>
    <h2>Data Stok Ikan</h2>
    
    <!-- Form Tambah Data Stok Ikan -->
    <form method="POST">
        <input type="text" name="jenis_ikan" placeholder="Jenis Ikan" required>
        <input type="number" name="jumlah" placeholder="Jumlah" required>
        <input type="text" name="harga_per_kg" placeholder="Harga per Kg" required>
        <button type="submit" name="add">Tambah</button>
    </form>

    <!-- Tabel Data Stok Ikan -->
    <table border="1">
        <tr>
            <th>Jenis Ikan</th>
            <th>Jumlah</th>
            <th>Harga per Kg</th>
            <th>Aksi</th>
        </tr>
        <?php while ($row = $stok_result->fetch_assoc()): ?>
        <tr>
            <td><?php echo $row['jenis_ikan']; ?></td>
            <td><?php echo $row['jumlah']; ?></td>
            <td><?php echo $row['harga_per_kg']; ?></td>
            <td>
                <a href="edit_stok_ikan.php?id=<?php echo $row['id']; ?>">Edit</a> |
                <a href="delete_stok_ikan.php?id=<?php echo $row['id']; ?>" onclick="return confirm('Yakin ingin menghapus data ini?');">Hapus</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>
