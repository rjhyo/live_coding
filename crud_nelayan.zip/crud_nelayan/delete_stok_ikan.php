<?php
session_start();
include 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Query untuk menghapus data stok ikan berdasarkan ID
    $stmt = $conn->prepare("DELETE FROM stok_ikan WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
}

header("Location: stok_ikan.php");
exit;
