<?php
session_start();
include 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Query untuk mendapatkan data stok ikan berdasarkan ID
    $stmt = $conn->prepare("SELECT * FROM stok_ikan WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $stok_ikan = $result->fetch_assoc();
    $stmt->close();

    if (!$stok_ikan) {
        echo "Data stok ikan tidak ditemukan.";
        exit;
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $jenis_ikan = $_POST['jenis_ikan'];
    $stok = $_POST['stok'];

    // Query untuk memperbarui data stok ikan
    $stmt = $conn->prepare("UPDATE stok_ikan SET jenis_ikan = ?, stok = ? WHERE id = ?");
    $stmt->bind_param("sii", $jenis_ikan, $stok, $id);
    $stmt->execute();
    $stmt->close();

    header("Location: stok_ikan.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Stok Ikan</title>
</head>
<body>
    <h2>Edit Stok Ikan</h2>
    <form method="POST">
        <input type="text" name="jenis_ikan" value="<?php echo $stok_ikan['jenis_ikan']; ?>" required><br><br>
        <input type="number" name="stok" value="<?php echo $stok_ikan['stok']; ?>" required><br><br>
        <button type="submit">Update</button>
    </form>
</body>
</html>
