<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Landing Page</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <h1>Selamat Datang di Sistem Informasi Nelayan</h1>
    <p><a href="register.php">Daftar</a> | <a href="login.php">Masuk</a></p>
</body>
</html>
