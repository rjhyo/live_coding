<?php
session_start();
include 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Query untuk mendapatkan data nelayan berdasarkan ID
    $stmt = $conn->prepare("SELECT * FROM nelayan WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $nelayan = $result->fetch_assoc();
    $stmt->close();

    if (!$nelayan) {
        echo "Data nelayan tidak ditemukan.";
        exit;
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama = $_POST['nama'];
    $alamat = $_POST['alamat'];
    $telepon = $_POST['telepon'];

    // Query untuk memperbarui data nelayan
    $stmt = $conn->prepare("UPDATE nelayan SET nama = ?, alamat = ?, telepon = ? WHERE id = ?");
    $stmt->bind_param("sssi", $nama, $alamat, $telepon, $id);
    $stmt->execute();
    $stmt->close();

    header("Location: nelayan.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Data Nelayan</title>
</head>
<body>
    <h2>Edit Data Nelayan</h2>
    <form method="POST">
        <input type="text" name="nama" value="<?php echo $nelayan['nama']; ?>" required><br><br>
        <input type="text" name="alamat" value="<?php echo $nelayan['alamat']; ?>" required><br><br>
        <input type="text" name="telepon" value="<?php echo $nelayan['telepon']; ?>" required><br><br>
        <button type="submit">Update</button>
    </form>
</body>
</html>
